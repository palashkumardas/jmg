<!-- ----------banner-section-start----------- -->
<section class="banner_section">
    <div class="container">
        <div class="banner_content">
         <div class="row">
            <div class="col-md-8 col-lg-8 col-12">
                <div class="banner_content_top" data-aos="fade-up">
                    <h1>transfer money across world in real time</h1>
                    <p>Simple to use with every feature and fcationality within reach and send money easily within your
                        limitation where ever you want
                    </p>
                    <a href="https://worldwide.jmgremit.co.uk/"><button data-aos="fade-up" >get started</button></a>

                 </div>
                 <p class="banner_bottom_p" data-aos="fade-up">send a receive money to your loved ones in minutes with great rates and low fees</p>
        <p class="banner_bottom_p_i" data-aos="fade-up">why chose us ?</p>
            </div>
            <div class="col-md-4 col-lg-4 col-12 mt-0" data-aos="fade-up">
                <iframe src="https://worldwidesvc.co.uk/shacal/indexv2.php?aid=6ca8c12f-2eb9-42cd-a99a-b6378a421c95" style="border:0px #ffffff none;border-radius:5px;" name="myiFrame" scrolling="no" frameborder="1" marginheight="0px" marginwidth="0px" height="430px" width="115%" allowfullscreen></iframe>
                {{-- <iframe src="https://www.worldwidesvc.co.uk/shacal/indexv2.php?aid=6ca8c12f-2eb9-42cd-a99a-b6378a421c95" style="border:0px #ffffff none;" name="myiFrame" scrolling="no" frameborder="1" marginheight="0px" marginwidth="0px" height="350px" width="110%" allowfullscreen></iframe> --}}
                {{-- <iframe src="https://worldwidesvc.co.uk/shacal/indexv2.php?aid=6ca8c12f-2eb9-42cd-a99a-b6378a421c95" style="border:0px #ffffff none;" name="myiFrame" scrolling="no" frameborder="1" marginheight="0px" marginwidth="0px" height="350px" width="110%" allowfullscreen></iframe> --}}
                <div class="text-center">
                    <p class="text-white" style="font-size:14px"><strong>Powered By</strong> <img src="frontend/assets/img/logo-white.png" alt=""  style="width:100px"></p>
                  </div>
            </div>
         </div>
        
        
       <div class="d-none d-md-block">
        <div  class="d-flex justify-content-left align-items-center banner_flex " data-aos="fade-left" >
            <p><i class="fas fa-check-circle"></i> Easy to use</p>
            <p><i class="fas fa-check-circle"></i> Faster Payments</p>
            <p><i class="fas fa-check-circle"></i> Low Fees</p>
            <p><i class="fas fa-check-circle"></i> 100% secure</p>
        </div>
       </div>
        <div class="d-flex justify-content-center align-items-center banner_flex d-block d-md-none" >
            <p ><i class="fas fa-check-circle"></i> Easy to use</p>
            <p ><i class="fas fa-check-circle"></i> Faster Payments</p>
        </div>
        <div class="d-flex justify-content-center align-items-center banner_flex d-block d-md-none mt-3" data-aos="fade-rigt">
            <p><i class="fas fa-check-circle"></i> Low Fees</p>
            <p><i class="fas fa-check-circle"></i> 100% secure</p>
        </div>
        </div>
    </div>
</section>